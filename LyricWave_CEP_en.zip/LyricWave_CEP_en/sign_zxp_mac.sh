#!/bin/bash
# Make a signed LyricWave_en.zxp for distribution (macOS). Needs ZXPSignCmd (Adobe CEP-Resources, "ZXPSignCMD")
# next to this file or on PATH. The self-signed certificate is created once (lyricwave_cert.p12) and reused.
set -e
cd "$(dirname "$0")"
Z=./ZXPSignCmd; [ -x "$Z" ] || Z=ZXPSignCmd
PASS="${LyricWave_CERT_PASS:-change-this-password}"
[ -f lyricwave_cert.p12 ] || "$Z" -selfSignedCert JP Tokyo LyricWave LyricWave "$PASS" lyricwave_cert.p12
rm -f LyricWave_en.zxp
"$Z" -sign com.duyhuongngv2.lyricwave LyricWave_en.zxp lyricwave_cert.p12 "$PASS" -tsa http://timestamp.digicert.com
"$Z" -verify LyricWave_en.zxp
echo "LyricWave_en.zxp ready"
