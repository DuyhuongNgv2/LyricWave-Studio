# LyricWave Studio — After Effects パネル（CEP 版）

ブラウザ版 LyricWave の画面を、そのまま After Effects の中で使えるパネルです。構成を決めて「AEでコンポを生成」を押すと、その場で編集できるコンポが組み上がります（JSON の書き出し・読み込みは不要です）。

- 対応：After Effects 2022（22.0）以降（Windows / Mac）
- 中身：`com.duyhuongngv2.lyricwave` フォルダがパネル本体です。

## 入れ方（いちばん簡単な方法）

1. このフォルダ一式を、分かりやすい場所に置きます（中の `com.duyhuongngv2.lyricwave` を移動しないでください）。
2. OS に合わせてインストール用のファイルを実行します。
   - **Mac**：`install_mac.command` をダブルクリックします。「開けません」と出たら、右クリック →「開く」を選びます。
   - **Windows**：`install_win.bat` をダブルクリックします。
3. After Effects を再起動し、メニューの **ウィンドウ → エクステンション → LyricWave Studio** を開きます。

インストール用のファイルは、次の2つを行います。

- `com.duyhuongngv2.lyricwave` を、ユーザーの CEP エクステンションのフォルダにコピーする
  - Mac：`~/Library/Application Support/Adobe/CEP/extensions/`
  - Windows：`%APPDATA%\Adobe\CEP\extensions\`
- 署名なしのパネルを読み込めるようにする（Adobe の「PlayerDebugMode」の設定。CSXS 10〜14）

手作業で入れる場合は、上の2つを自分で行ってください。

## 使い方

- 歌詞・スタイル・演出を決める操作は、ブラウザ版と同じです。プレビューもパネルの中で動きます。
- **AEでコンポを生成**（画面右上、かんたんモードでは書き出し欄）：今の構成で新しいコンポを作ります。1回の生成は 1 回の「取り消し」で戻せます。
- **AEで選択中の曲**（曲とタイミング欄）：AE で開いているコンポの、曲のレイヤーを選んでから押します。曲を解析して拍に合わせます。コンポを作るときに、その曲のレイヤーも入ります。
- **AEのマーカーを行頭に**：選択したレイヤー（無ければコンポ）のマーカーを、各行の開始時刻にします。曲のレイヤーを選んでいるときは、曲の頭からの時刻に直して使います。
- 画面比・解像度・fps・背景（通常 / グリーンバック / ブラックバック）は、書き出し欄の設定がそのままコンポに使われます。
- MP4・連番PNG の書き出しもパネルから使えます。保存先はダイアログで選びます。お使いの AE のパネル環境が MP4 の書き出しに対応していない場合は、書き出し欄にそう表示されます（そのときは連番PNG を使うか、AE でレンダリングしてください）。
- 書体は、スクリプト版パネル（`LyricWave_AE.jsx`）の「フォント」タブで設定した内容を使います。未設定のときは PC に入っている書体から自動で選びます。
- **診断レポートを保存**（書き出しタブの After Effects 欄）：最後に作ったコンポのエクスプレッションを AE に計算させて、エラーや置き換えを `LyricWave_report.txt` にまとめます。思ったとおりにできないときは、このファイルを添えて報告してください。

## 配布用の .zxp を作る（配布する人向け）

1. Adobe の署名ツール **ZXPSignCmd** を入手します（GitHub の Adobe-CEP / CEP-Resources にあります）。このフォルダに置くか、PATH を通します。
2. `sign_zxp_mac.sh`（Mac）または `sign_zxp_win.bat`（Windows）を実行すると、自己署名の証明書を作って `LyricWave.zxp` を作ります。パスワードは環境変数 `LyricWave_CERT_PASS` で指定できます。
3. 受け取った人は、aescripts の「ZXP Installer」などで `LyricWave.zxp` をインストールします。この場合、PlayerDebugMode の設定は不要です。

## うまく動かないとき

- メニューに出てこない：After Effects を完全に終了してから開き直してください。PlayerDebugMode の設定が効いていない場合は、インストール用のファイルをもう一度実行してください。
- 「After Effects に接続できませんでした」：パネルを閉じて開き直してください。`com.duyhuongngv2.lyricwave/jsx/` の中に `host.jsx` と `lyricwave_core.jsx` があるか確認してください。
- コンポの作成で問題が出た項目は、パネルの書き出し欄に件数が表示されます。
